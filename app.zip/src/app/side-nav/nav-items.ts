export class NavItem {
    'icon': string;
    'text': string;
}
export const MAINNAVITEMS: NavItem[] = [
    {icon: 'home',text: 'Component configuration'},
    {icon: 'watch_later',text: 'Watch later'},
    {icon: 'visibility',text: 'Visibility'},
    {icon: 'work',text: 'Work'}
];
