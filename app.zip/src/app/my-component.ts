/*
export class MyComponent {

    constructor(
      public id: number,
      public componentLabel: string= '',
      public componentDesc: string= '',
      public componentType: string= '',
      public assessmentGroup: string= '',
      public dataType: string= '',
      public maxScore: string= '',
      public passingScore: string= '',
      public calcMethode: string= ''
    ) {  }
  
  }

*/
  export class MyComponent{
    id: number;
    componentLabel: string;
    componentDesc: string;
    componentType: string;
    assessmentGroup: string;
    dataType: string;
    maxScore: string;
    passingScore: string;
    calcMethode: string;
  }